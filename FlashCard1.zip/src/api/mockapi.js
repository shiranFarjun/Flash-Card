import axios from 'axios';

export default axios.create({
  baseURL: 'https://5f6cb19834d1ef0016d587bd.mockapi.io/'
});

