// import mockapi from '../api/mockapi';


// const postNewCard = async (newObj,props) => {
//     const response = await mockapi.post('/card', newObj);
//     props.packCards=response.data
//     console.log("in postNewCard -->props!!", props.packCards);
// }
// export default postNewCard;
