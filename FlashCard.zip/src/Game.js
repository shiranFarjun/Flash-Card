import React from 'react';
// import mockapi from './api/mockapi';
// import ObjCard from './ObjCard.js'

class Game extends React.Component {
    state = {
        question: ' ',
        answer: ' '
    }

    componentDidMount=()=> {
        console.log('question this.props.packCards[0][question] \n ', this.props.packCards[0]['question']);
        console.log('answer  this.props.packCards[0][answer]  \n', this.props.packCards[0]['answer']);
        this.setState({
            question: this.props.packCards[0]['question'],
            answer: this.props.packCards[0]['answer']
        });
        console.log(this.state.question);
        console.log(this.state.answer);
    }

    getRandomCard() {
        let card = Math.floor(Math.random() * Math.floor(this.props.packCards[0]));
        return (card);
    }

    render() {
        return (
            <div className="continer-game" >
                <div className="view-card">{this.state.question}</div>
                <button>New card</button>
                <button>Reveal answaer</button>
                <p>Did you get it right? </p>
                <p>completed: </p>
                <p>0/3</p>
            </div>
        );
    };
};

export default Game;

